"use client";

import { useState, useEffect } from "react";
import html2canvas from "html2canvas";

export default function Home() {
    const [colors, setColors] = useState([]);

    async function gerarPaleta() {
        try {
            const response = await fetch("SUA API DE CORES");
            if (!response.ok) throw new Error("Falha ao buscar paleta de cores");

            const data = await response.json();
            if (!data?.schemes?.[0]?.Colors) throw new Error("Dados de paleta inválidos");

            const novaCor = data.schemes[0].Colors.map(color => `#${color}`);
            setColors(novaCor);
        } catch (error) {
            console.error("Erro ao gerar paleta:", error);
            alert("Ocorreu um erro ao gerar a paleta. Tente novamente.");
        }
    }

    function copiar(text) {
        navigator.clipboard.writeText(text).then(() => {
            alert(`Copiado: ${text}`);
        }).catch(err => {
            console.error("Erro ao copiar cor:", err);
            alert("Erro ao copiar cor. Tente novamente.");
        });
    }

    function salvarPaleta() {
        const paletteElement = document.getElementById("palette");
        if (!paletteElement) {
            alert("Erro ao salvar paleta. Elemento não encontrado.");
            return;
        }

        html2canvas(paletteElement).then(canvas => {
            const link = document.createElement("a");
            link.href = canvas.toDataURL("image/png");
            link.download = "paleta.png";
            link.click();
        }).catch(err => {
            console.error("Erro ao salvar paleta:", err);
            alert("Erro ao salvar paleta. Tente novamente.");
        });
    }

    useEffect(() => {
        gerarPaleta();
    }, []);

    return (
        <main className="flex flex-col items-center p-4 min-h-screen bg-gray-100">
            <h1 className="text-2xl font-bold mb-4">Gerador de Paleta de Cores</h1>
            <div id="palette" className="flex gap-2 mb-4">
                {colors.map(color => {
                    const brightness = getBrightness(color);
                    const textColor = brightness > 186 ? "black" : "white";

                    return (
                        <div
                            key={color}
                            className="w-20 h-20 flex items-center justify-center text-sm font-bold cursor-pointer shadow-md"
                            style={{ background: color, color: textColor }}
                            onClick={() => copiar(color)}
                            aria-label={`Copiar cor ${color}`}
                        >
                            {color}
                        </div>
                    );
                })}
            </div>
            <button className="bg-blue-500 text-white px-4 py-2 rounded m-2 shadow-md" onClick={gerarPaleta}>
                Gerar Paleta
            </button>
            <button className="bg-green-500 text-white px-4 py-2 rounded m-2 shadow-md" onClick={salvarPaleta}>
                Salvar Paleta
            </button>
        </main>
    );
}

function getBrightness(hex) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return (r * 299 + g * 587 + b * 114) / 1000;
}